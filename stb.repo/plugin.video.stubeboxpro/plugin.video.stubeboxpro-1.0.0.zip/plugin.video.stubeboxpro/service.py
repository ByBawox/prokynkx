# StubeBoxPro Arka Plan Servisi
import xbmc
xbmc.log('StubeBoxPro servisi aktif.', xbmc.LOGINFO)