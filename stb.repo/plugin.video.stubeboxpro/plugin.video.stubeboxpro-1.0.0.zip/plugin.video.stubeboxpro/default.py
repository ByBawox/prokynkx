# StubeBoxPro Ana Çalıştırma Kodları
import xbmcgui
xbmcgui.Dialog().ok('StubeBoxPro', 'Eklenti Başarıyla Çalıştı!')